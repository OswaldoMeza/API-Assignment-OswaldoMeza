Google Maps API should not need a new Key since I don't have any restrictions applied.

My project is different from the proposal I've made because I didn't check the APIs when I proposed that Assignment. The love Calculator API is no longer working or being supported, so I came up with this new idea.

You made need to instal Node package for the PokeAPI:

npm install pokeapi-js-wrapper --save